package com.example.noteeapp;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class noteDetails extends AppCompatActivity {
    String subject;
    TextView note_subject,body;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notedetails);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Details");
        note_subject = findViewById(R.id.subject);
        body = findViewById(R.id.body);
        Bundle bundle = getIntent().getExtras();
        subject = bundle.getString("message");
       DB db = new DB(this);
        Note note = db.getNote(subject);
        body.setText(note.getBody());
        note_subject.setText(note.getSubject());

    }
}
